Photodetector trace data.

File g112APDtraces.csv and g112APDtraces.npy contain 6 columns of data:
	- Columns 1 & 2 are data for the highest higher illumination;
	- Columns 3 & 4 are data for medium illumination;
	- Columns 5 & 6 are data for the lowest illumination.

In each pair of columns, the first entry is time in seconds;
the second entry is detector output in volts at that time.

Data courtesy John Beausang.
