population.mat, population.csv, and population.npy:
	Column 1:	date in years CE.
	Column 2:	Estimated world population.

Data from http://www.vaughns-1-pagers.com/history/world-population-growth.htm

See also
http://www.census.gov/population/international/data/idb/worldpopinfo.php
