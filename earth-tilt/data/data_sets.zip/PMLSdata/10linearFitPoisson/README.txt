Radioactive decay data.

linearFitPoisson.mat: 
	- xvals = 1/(distance from radioactive source to detector in m)^2 
	- counts = counts in detector in a fixed time interval

linearFitPoisson.csv and linearFitPoisson.npy:
	- First column = xvals
	- Second column = counts
